import { StyleSheet, Text, TextInput, TouchableOpacity, View, type TextInputProps } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { colors, fonts } from '@/lib/theme';

export function FieldLabel({ children }: { children: string }) {
  return <Text style={styles.fieldLabel}>{children}</Text>;
}

export function TextField(props: TextInputProps) {
  return <TextInput placeholderTextColor={colors.inkFaint} style={styles.input} {...props} />;
}

export function TextArea(props: TextInputProps) {
  return (
    <TextInput
      placeholderTextColor={colors.inkFaint}
      multiline
      textAlignVertical="top"
      style={[styles.input, styles.textArea]}
      {...props}
    />
  );
}

export function Segmented<T extends string>({
  options,
  value,
  onChange,
}: {
  options: { value: T; label: string }[];
  value: T;
  onChange: (v: T) => void;
}) {
  return (
    <View style={styles.segmented}>
      {options.map((opt, i) => {
        const active = opt.value === value;
        return (
          <TouchableOpacity
            key={opt.value}
            onPress={() => onChange(opt.value)}
            style={[
              styles.segmentedOption,
              i > 0 && styles.segmentedOptionBorder,
              active && styles.segmentedOptionActive,
            ]}
            accessibilityRole="button">
            <Text style={[styles.segmentedLabel, active && styles.segmentedLabelActive]}>{opt.label}</Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

export function Stepper({
  value,
  onChange,
  eenheid,
  min = 0,
}: {
  value: number;
  onChange: (v: number) => void;
  eenheid: string;
  min?: number;
}) {
  return (
    <View style={styles.stepperRow}>
      <View style={styles.stepper}>
        <TouchableOpacity
          style={styles.stepperBtn}
          onPress={() => onChange(Math.max(min, value - 1))}
          accessibilityRole="button">
          <Ionicons name="remove" size={18} color={colors.ink} />
        </TouchableOpacity>
        <Text style={styles.stepperValue}>{value}</Text>
        <TouchableOpacity
          style={[styles.stepperBtn, styles.stepperBtnRight]}
          onPress={() => onChange(value + 1)}
          accessibilityRole="button">
          <Ionicons name="add" size={18} color={colors.ink} />
        </TouchableOpacity>
      </View>
      <Text style={styles.eenheid}>{eenheid}</Text>
    </View>
  );
}

export function ToggleRow({
  checked,
  onToggle,
  titel,
  sub,
}: {
  checked: boolean;
  onToggle: () => void;
  titel: string;
  sub: string;
}) {
  return (
    <TouchableOpacity style={styles.toggleRow} onPress={onToggle} accessibilityRole="button">
      <View style={[styles.checkbox, checked && styles.checkboxOn]}>
        {checked ? <Ionicons name="checkmark" size={14} color={colors.white} /> : null}
      </View>
      <View style={{ flex: 1 }}>
        <Text style={styles.toggleTitel}>{titel}</Text>
        <Text style={styles.toggleSub}>{sub}</Text>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  fieldLabel: {
    fontFamily: fonts.monoMedium,
    fontSize: 11,
    letterSpacing: 0.8,
    textTransform: 'uppercase',
    color: colors.inkMuted,
    marginBottom: 7,
  },
  input: {
    minHeight: 44,
    paddingHorizontal: 10,
    borderWidth: 1,
    borderColor: colors.dividerStrong,
    backgroundColor: colors.white,
    fontFamily: fonts.body,
    fontSize: 15,
    color: colors.ink,
  },
  textArea: { minHeight: 76, paddingTop: 10 },
  segmented: { flexDirection: 'row', borderWidth: 1, borderColor: colors.dividerStrong },
  segmentedOption: { flex: 1, minHeight: 44, alignItems: 'center', justifyContent: 'center' },
  segmentedOptionBorder: { borderLeftWidth: 1, borderLeftColor: colors.dividerStrong },
  segmentedOptionActive: { backgroundColor: colors.accent },
  segmentedLabel: {
    fontFamily: fonts.heading,
    fontSize: 12,
    letterSpacing: 0.8,
    textTransform: 'uppercase',
    color: colors.ink,
  },
  segmentedLabelActive: { color: colors.white },
  stepperRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  stepper: { flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderColor: colors.dividerStrong },
  stepperBtn: { width: 44, height: 44, alignItems: 'center', justifyContent: 'center', borderRightWidth: 1, borderRightColor: colors.dividerStrong },
  stepperBtnRight: { borderRightWidth: 0, borderLeftWidth: 1, borderLeftColor: colors.dividerStrong },
  stepperValue: { minWidth: 44, textAlign: 'center', fontFamily: fonts.monoMedium, fontSize: 16, color: colors.ink },
  eenheid: { fontFamily: fonts.mono, fontSize: 12, color: colors.inkMuted },
  toggleRow: { flexDirection: 'row', alignItems: 'center', gap: 10, minHeight: 44 },
  checkbox: { width: 22, height: 22, borderWidth: 1, borderColor: colors.dividerStrong, alignItems: 'center', justifyContent: 'center' },
  checkboxOn: { backgroundColor: colors.accent, borderColor: colors.accentDark },
  toggleTitel: { fontFamily: fonts.bodyMedium, fontSize: 14, color: colors.ink },
  toggleSub: { fontFamily: fonts.body, fontSize: 11.5, color: colors.inkMuted },
});
